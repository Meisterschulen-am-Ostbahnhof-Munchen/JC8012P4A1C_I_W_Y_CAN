G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.8*
G04 #@! TF.CreationDate,2026-11-01T09:46:17+01:00*
G04 #@! TF.ProjectId,JC8012P4A1C_backplate,4a433830-3132-4503-9441-31435f626163,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8) date 2026-11-01 09:46:17*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,3.200000*%
%ADD11C,5.400000*%
%ADD12RoundRect,4.700000X-0.000010X-0.000010X0.000010X-0.000010X0.000010X0.000010X-0.000010X0.000010X0*%
G04 APERTURE END LIST*
D10*
X265700000Y-173600000D03*
X210000000Y-176350000D03*
D11*
X200000000Y-50000000D03*
D12*
X200000000Y-50000000D03*
D10*
X34300000Y-26400000D03*
D11*
X100000000Y-150000000D03*
D12*
X100000000Y-150000000D03*
D10*
X34300000Y-173600000D03*
X90000000Y-176350000D03*
X265700000Y-26400000D03*
X90000000Y-23650000D03*
X210000000Y-23650000D03*
D11*
X200000000Y-150000000D03*
D12*
X200000000Y-150000000D03*
D11*
X100000000Y-50000000D03*
D12*
X100000000Y-50000000D03*
M02*
